import {test,expect} from "@playwright/test"

test.use({
  viewport: null,
  launchOptions: {
    args: ['--start-maximized'],
  },
});

test('@Web Client App login', async ({ page }) => {
   //js file- Login js, DashboardPage
   const email = "jaychandra.qa@gmail.com";
  
    const products = page.locator(".card-body");
   const productName='ZARA COAT 3';
  
   await page.goto("https://rahulshettyacademy.com/client");
   await page.locator("#userEmail").fill(email);
   await page.locator("#userPassword").fill("Chandra@123");
   await page.locator("[value='Login']").click();
  //await page.waitForLoadState('networkidle');
   await page.locator(".card-body b").first().waitFor();
   const titles = await page.locator(".card-body b").allTextContents();
   console.log(titles);
   const count=await products.count();

   for(let i=0;i<count;i++)
   {
     
     if(await products.nth(i).locator("b").textContent() === productName)
     {
     
        await products.nth(i).locator("text= Add To Cart").click();
        break;
     }
   }
   await page.locator("[routerlink*='cart']").click();
   await page.locator('div li').first().waitFor();
   const bool=await page.locator("h3:has-text('ZARA COAT 3')").isVisible();
   expect(bool).toBeTruthy(); //if its displayed truth

   await page.locator("text=Checkout").click();

   await page.locator("[placeholder*='Country']").pressSequentially("ind");

   const dropdown= page.locator('.ta-results')
   await dropdown.waitFor();
   const optionsCount=await dropdown.locator('button').count();

   for(let i=0;i<optionsCount;i++)
   {
      const text = await dropdown.locator('button').nth(i).textContent();
      if(text===' India')
      {
      await dropdown.locator('button').nth(i).click();
      break;
      }
   }
await expect(page.locator(".user__name [type='text']").first()).toHaveText("jaychandra.qa@gmail.com");
await page.locator(".action__submit").click();

await expect(page.locator(".hero-primary")).toHaveText(" Thankyou for the order. ");
const orderId=await page.locator(".em-spacer-1 .ng-star-inserted").textContent();
console.log(orderId);
await page.locator("button[routerlink*='myorders']").click();
await page.locator("tbody").waitFor();
const rows=await page.locator('tbody tr');
const rowscount=await rows.count();
for(let i=0;i<rowscount;i++)
{
   const rowOrderId=await rows.nth(i).locator("th").textContent();
   
   if(orderId?.includes(rowOrderId))
   {
      await rows.nth(i).locator("button").first().click();
      break;
   }
}
const orderIdDetails=await page.locator(".col-text").textContent();
expect(orderId?.includes(orderIdDetails)).toBeTruthy();
});
